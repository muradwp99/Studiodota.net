/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u781705420_sbdb
-- ------------------------------------------------------
-- Server version	11.8.8-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `Booking`
--

DROP TABLE IF EXISTS `Booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Booking` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `topic` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `requestedSlot` datetime(3) NOT NULL,
  `durationMins` int(11) NOT NULL DEFAULT 30,
  `status` enum('PENDING','CONFIRMED','DECLINED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `meetLink` text DEFAULT NULL,
  `googleEventId` varchar(191) DEFAULT NULL,
  `adminNote` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Booking_status_idx` (`status`),
  KEY `Booking_requestedSlot_idx` (`requestedSlot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Booking`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Booking` DISABLE KEYS */;
INSERT INTO `Booking` VALUES
('cmrhsgaxm0000va8ggi26xvrb','Test Client','test@example.com',NULL,NULL,'Market expansion',NULL,'2026-07-20 10:00:00.000',30,'PENDING',NULL,NULL,NULL,'2026-07-12 12:47:28.090','2026-07-12 12:47:28.090');
/*!40000 ALTER TABLE `Booking` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `CaseStudy`
--

DROP TABLE IF EXISTS `CaseStudy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CaseStudy` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `client` varchar(191) DEFAULT NULL,
  `industry` varchar(191) DEFAULT NULL,
  `service` varchar(191) DEFAULT NULL,
  `businessSize` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `coverUrl` text DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `challenge` longtext DEFAULT NULL,
  `research` longtext DEFAULT NULL,
  `strategy` longtext DEFAULT NULL,
  `implementation` longtext DEFAULT NULL,
  `results` longtext DEFAULT NULL,
  `kpis` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`kpis`)),
  `lessons` longtext DEFAULT NULL,
  `testimonial` text DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `seoTitle` varchar(191) DEFAULT NULL,
  `seoDesc` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CaseStudy_slug_key` (`slug`),
  KEY `CaseStudy_published_orderIndex_idx` (`published`,`orderIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CaseStudy`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `CaseStudy` DISABLE KEYS */;
/*!40000 ALTER TABLE `CaseStudy` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Certification`
--

DROP TABLE IF EXISTS `Certification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Certification` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `issuer` varchar(191) DEFAULT NULL,
  `year` varchar(191) DEFAULT NULL,
  `logoUrl` text DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Certification`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Certification` DISABLE KEYS */;
INSERT INTO `Certification` VALUES
('cmrhuwxd0001ovaogr9wfm8kv','BBA — Human Resource Management','Daffodil International University','2022',NULL,0,1),
('cmrhuwxl3001pvaog8ldn4ml3','Business Strategy Certification','Professional Program','2023',NULL,1,1),
('cmrhuwxqg001qvaoguiafcl0o','Growth Marketing','Executive Program','2023',NULL,2,1);
/*!40000 ALTER TABLE `Certification` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ClientLogo`
--

DROP TABLE IF EXISTS `ClientLogo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientLogo` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `logoUrl` text NOT NULL,
  `link` varchar(191) DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClientLogo`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `ClientLogo` DISABLE KEYS */;
INSERT INTO `ClientLogo` VALUES
('cmrhuwxzy001rvaogqkmd64hc','Realistic 3D','',NULL,0,1),
('cmrhuwy83001svaog7igteomc','Damex Digital','',NULL,1,1),
('cmrhuwydm001tvaogefo5r659','Orgagenic','',NULL,2,1),
('cmrhuwyj1001uvaog6rhm8b6k','Tools Lab','',NULL,3,1),
('cmrhuwyoi001vvaogblt6ntoj','Net Impact','',NULL,4,1),
('cmrhuwytw001wvaogaz90q48f','Hult Prize','',NULL,5,1);
/*!40000 ALTER TABLE `ClientLogo` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ContactMessage`
--

DROP TABLE IF EXISTS `ContactMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ContactMessage` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `company` varchar(191) DEFAULT NULL,
  `industry` varchar(191) DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `message` text NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `ContactMessage_read_idx` (`read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContactMessage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `ContactMessage` DISABLE KEYS */;
INSERT INTO `ContactMessage` VALUES
('cmrhsgbcq0001va8gs7hqjvgg','Jane Doe','jane@example.com',NULL,NULL,NULL,'Interested in brand positioning help.',0,'2026-07-12 12:47:28.635');
/*!40000 ALTER TABLE `ContactMessage` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Event`
--

DROP TABLE IF EXISTS `Event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Event` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `venue` varchar(191) DEFAULT NULL,
  `location` varchar(191) DEFAULT NULL,
  `eventDate` datetime(3) DEFAULT NULL,
  `upcoming` tinyint(1) NOT NULL DEFAULT 0,
  `coverUrl` text DEFAULT NULL,
  `videoUrl` text DEFAULT NULL,
  `link` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `Event_upcoming_eventDate_idx` (`upcoming`,`eventDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Event`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Event` DISABLE KEYS */;
/*!40000 ALTER TABLE `Event` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ExperienceItem`
--

DROP TABLE IF EXISTS `ExperienceItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExperienceItem` (
  `id` varchar(191) NOT NULL,
  `company` varchar(191) NOT NULL,
  `role` varchar(191) NOT NULL,
  `location` varchar(191) DEFAULT NULL,
  `startDate` varchar(191) DEFAULT NULL,
  `endDate` varchar(191) DEFAULT NULL,
  `current` tinyint(1) NOT NULL DEFAULT 0,
  `summary` text DEFAULT NULL,
  `logoUrl` text DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `ExperienceItem_orderIndex_idx` (`orderIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExperienceItem`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `ExperienceItem` DISABLE KEYS */;
INSERT INTO `ExperienceItem` VALUES
('cmrhuwuy7001avaog2mqc2i3u','Realistic 3D','Business Development Manager','United Kingdom','Mar 2026','Present',1,'Driving business development and strategic growth for a 3D visualization studio.',NULL,0,1),
('cmrhuwv69001bvaogoh24oys3','Damex Digital Ltd','Chief Operating Officer','British Columbia, Canada','Jun 2020','Present',1,'Leading operations, growth strategy and cross-functional execution as COO.',NULL,1,1),
('cmrhuwvbn001cvaogukxufta5','Orgagenic','HR & Operations Manager','Dhaka, Bangladesh','Oct 2024','Feb 2026',0,'Built high-performing teams and optimized operational processes.',NULL,2,1),
('cmrhuwvh0001dvaogkpu3c1q3','Tools Lab','Founder & COO','London, United Kingdom','Jan 2021','Dec 2022',0,'Founded and operated a tools venture end-to-end.',NULL,3,1),
('cmrhuwvme001evaogyj7k3jxq','Net Impact','Vice President','Dhaka, Bangladesh','Jan 2020','Dec 2022',0,'Led chapter initiatives focused on sustainable business impact.',NULL,4,1),
('cmrhuwvrt001fvaogkj8mgfml','Hult Prize at DIU','Assistant Director','Dhaka, Bangladesh','Aug 2019','Feb 2021',0,'Organized and mentored teams for the world\'s largest student social-enterprise competition.',NULL,5,1);
/*!40000 ALTER TABLE `ExperienceItem` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Faq`
--

DROP TABLE IF EXISTS `Faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Faq` (
  `id` varchar(191) NOT NULL,
  `question` text NOT NULL,
  `answer` longtext NOT NULL,
  `group` varchar(191) DEFAULT 'General',
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `Faq_group_orderIndex_idx` (`group`,`orderIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Faq`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Faq` DISABLE KEYS */;
INSERT INTO `Faq` VALUES
('cmrhuwzng0020vaogdx6jwbzz','How do engagements usually start?','Every engagement begins with a discovery call to understand your business, market and goals. From there I propose a scope — from a focused audit to a full growth roadmap with hands-on implementation.','Working process',0,1),
('cmrhuwzvk0021vaogapsvk563','How is pricing structured?','Pricing depends on scope and duration — from fixed-scope strategy sprints to retained advisory. You\'ll always get a clear proposal before any commitment.','Pricing',1,1),
('cmrhux00x0022vaogrda7dxg7','How long does a typical project take?','A strategy sprint runs 2–4 weeks; market-entry and transformation engagements typically span 2–6 months with ongoing optimization.','Timeline',2,1),
('cmrhux06b0023vaogi2u5le7g','Do you work with clients internationally?','Yes — I\'ve worked with teams across 15+ countries and run engagements remotely with periodic on-site sessions where needed.','Availability',3,1);
/*!40000 ALTER TABLE `Faq` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Industry`
--

DROP TABLE IF EXISTS `Industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Industry` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Industry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Industry` DISABLE KEYS */;
INSERT INTO `Industry` VALUES
('cmrhuwvzx001gvaogb93lkk8l','Technology','Cpu',0,1),
('cmrhuww7y001hvaogorv514v7','Healthcare','HeartPulse',1,1),
('cmrhuwwdd001ivaogwj350vzq','Manufacturing','Factory',2,1),
('cmrhuwwir001jvaogey1lma4z','Retail','ShoppingBag',3,1),
('cmrhuwwo5001kvaogwe45eqsn','SaaS','Cloud',4,1),
('cmrhuwwtk001lvaoghqxuicnk','Finance','Landmark',5,1),
('cmrhuwwyy001mvaog7553osnw','Real Estate','Building2',6,1),
('cmrhuwx4f001nvaog1omirah8','Education','GraduationCap',7,1);
/*!40000 ALTER TABLE `Industry` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Media`
--

DROP TABLE IF EXISTS `Media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Media` (
  `id` varchar(191) NOT NULL,
  `url` text NOT NULL,
  `filename` varchar(191) NOT NULL,
  `alt` varchar(191) DEFAULT NULL,
  `mimeType` varchar(191) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Media`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Media` DISABLE KEYS */;
/*!40000 ALTER TABLE `Media` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `MediaItem`
--

DROP TABLE IF EXISTS `MediaItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `MediaItem` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `outlet` varchar(191) DEFAULT NULL,
  `date` datetime(3) DEFAULT NULL,
  `thumbUrl` text DEFAULT NULL,
  `link` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `MediaItem_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MediaItem`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `MediaItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `MediaItem` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `NavItem`
--

DROP TABLE IF EXISTS `NavItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `NavItem` (
  `id` varchar(191) NOT NULL,
  `label` varchar(191) NOT NULL,
  `href` varchar(191) NOT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `location` varchar(191) NOT NULL DEFAULT 'header',
  `visible` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `NavItem_location_orderIndex_idx` (`location`,`orderIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NavItem`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `NavItem` DISABLE KEYS */;
INSERT INTO `NavItem` VALUES
('cmrhuwmvi0001vaogwugtpxpj','Home','/',0,'header',1),
('cmrhuwn3t0002vaogbvj8sjb2','About','/about',1,'header',1),
('cmrhuwn9a0003vaog7tl4vkf6','Services','/services',2,'header',1),
('cmrhuwnet0004vaogr2905xn1','Case Studies','/case-studies',3,'header',1),
('cmrhuwnkc0005vaogjrqxg55d','Portfolio','/portfolio',4,'header',1),
('cmrhuwnpt0006vaogfkjl4teh','Insights','/blog',5,'header',1),
('cmrhuwnvc0007vaogq73hb30o','Testimonials','/testimonials',6,'header',1),
('cmrhuwo0r0008vaog2pgz53d2','Contact','/contact',7,'header',1),
('cmrhuwo650009vaog6d8p7xp8','Services','/services',0,'footer',1),
('cmrhuwoby000avaogaqargymh','Case Studies','/case-studies',1,'footer',1),
('cmrhuwohc000bvaogolyeeo9r','Resources','/resources',2,'footer',1),
('cmrhuwomq000cvaoglc52zblx','FAQ','/faq',3,'footer',1),
('cmrhuwos5000dvaog7dsi3s8e','Privacy Policy','/privacy',4,'footer',1),
('cmrhuwoxk000evaogdqtlqq4n','Terms & Conditions','/terms',5,'footer',1);
/*!40000 ALTER TABLE `NavItem` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `NewsletterSubscriber`
--

DROP TABLE IF EXISTS `NewsletterSubscriber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `NewsletterSubscriber` (
  `id` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `source` varchar(191) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `NewsletterSubscriber_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NewsletterSubscriber`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `NewsletterSubscriber` DISABLE KEYS */;
INSERT INTO `NewsletterSubscriber` VALUES
('cmrhsgbqr0002va8g88kcgm6m','sub@example.com',NULL,'footer',1,'2026-07-12 12:47:29.139');
/*!40000 ALTER TABLE `NewsletterSubscriber` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `PageSection`
--

DROP TABLE IF EXISTS `PageSection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PageSection` (
  `id` varchar(191) NOT NULL,
  `pageKey` varchar(191) NOT NULL,
  `sectionKey` varchar(191) NOT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PageSection_pageKey_sectionKey_key` (`pageKey`,`sectionKey`),
  KEY `PageSection_pageKey_idx` (`pageKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PageSection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `PageSection` DISABLE KEYS */;
INSERT INTO `PageSection` VALUES
('cmrhsdzlb000fvangc4l55uvt','home','hero',0,'{\"availability\":\"Available for Work\",\"intro\":\"Hi, I\'m Safiul — I help companies drive strategic growth, sharpen brand positioning, and expand into new markets with AI-driven strategy.\",\"primaryCta\":{\"label\":\"See my works\",\"href\":\"/works\"},\"portraitUrl\":\"/hero-cutout.png\",\"slides\":[{\"label\":\"Positioning\",\"title\":\"Business & Growth Strategist based in Dhaka.\"},{\"label\":\"Experience\",\"title\":\"8+ years across strategy, operations & leadership.\"},{\"label\":\"Reach\",\"title\":\"Serving 18 industries across 15+ countries.\"},{\"label\":\"Impact\",\"title\":\"$30M+ revenue influenced · 120+ businesses helped.\"},{\"label\":\"Approach\",\"title\":\"Market insight × creativity × technology = growth.\"}]}',1,'2026-07-12 13:56:12.155'),
('cmrhsdzw5000gvang3vjrbsaa','home','trustedBy',1,'{\"label\":\"Trusted by teams across 15+ countries\"}',1,'2026-07-12 13:56:12.543'),
('cmrhse02w000hvang0x3r9khs','home','aboutSnapshot',2,'{\"eyebrow\":\"About\",\"title\":\"Strategy, brand and execution — under one roof.\",\"body\":\"With experience spanning business strategy, development and growth marketing, I turn opportunities into scalable outcomes. My work sits where market insight meets creativity and technology — building strategic partnerships and solutions that create long-term business value.\",\"highlights\":[{\"value\":\"8+\",\"label\":\"Years across strategy & operations\"},{\"value\":\"18\",\"label\":\"Industries served\"},{\"value\":\"15+\",\"label\":\"Countries\"}],\"cta\":{\"label\":\"More about me\",\"href\":\"/about\"}}',1,'2026-07-12 13:56:12.786'),
('cmrhse09q000ivangwspx2khz','home','servicesIntro',3,'{\"eyebrow\":\"What I do\",\"title\":\"Services built around measurable growth.\",\"subtitle\":\"From strategic audits to go-to-market execution — engagements shaped to your stage and ambition.\"}',1,'2026-07-12 13:56:13.030'),
('cmrhse0gj000jvangtnuzlo1k','home','resultsIntro',4,'{\"eyebrow\":\"Results & Impact\",\"title\":\"Outcomes that compound.\"}',1,'2026-07-12 13:56:13.271'),
('cmrhse0nc000kvanglof5iil4','home','whyIntro',5,'{\"eyebrow\":\"Why work with me\",\"title\":\"A strategist who ships, not just advises.\"}',1,'2026-07-12 13:56:13.515'),
('cmrhse0ua000lvangeuyrs4q4','home','cta',6,'{\"title\":\"Ready to unlock your next stage of growth?\",\"subtitle\":\"Book a strategy session and leave with a clear, prioritized plan for your business.\",\"primaryCta\":{\"label\":\"Book a Strategy Session\",\"href\":\"/book\"},\"secondaryCta\":{\"label\":\"Get in touch\",\"href\":\"/contact\"}}',1,'2026-07-12 13:56:13.758'),
('cmrhse11b000mvangwehtlkox','about','hero',0,'{\"eyebrow\":\"About\",\"title\":\"I build businesses that are meant to scale.\",\"subtitle\":\"Business strategist, operator and brand builder — helping founders and leadership teams turn ambition into structured, measurable growth.\",\"portraitUrl\":\"/portrait.png\"}',1,'2026-07-12 13:56:14.000'),
('cmrhse18d000nvang5nnt0216','about','story',1,'{\"eyebrow\":\"My story\",\"title\":\"From operations to strategy leadership.\",\"body\":\"<p>I believe sustainable business growth is driven by strategy, strong branding, and smart execution. My passion is helping businesses expand into new markets, build impactful brands, and leverage AI-driven marketing to achieve measurable results.</p><p>Across roles in business strategy, development and growth marketing, I\'ve enjoyed turning ideas into scalable opportunities by combining market insights, creativity and technology. My journey through Human Resources, Operations and Leadership strengthened my ability to build high-performing teams, optimize processes, and align people with business goals.</p>\"}',1,'2026-07-12 13:56:14.245'),
('cmrhse1f3000ovang30vbmswg','about','philosophy',2,'{\"eyebrow\":\"How I think\",\"mission\":\"To help ambitious businesses grow with clarity — turning strategy into execution and execution into measurable value.\",\"vision\":\"A world where great ideas aren\'t limited by borders, but scaled through smart strategy and technology.\",\"values\":[{\"title\":\"Clarity over complexity\",\"desc\":\"Strategy that a team can actually execute.\"},{\"title\":\"Evidence over opinion\",\"desc\":\"Decisions grounded in market data and results.\"},{\"title\":\"Partnership over hierarchy\",\"desc\":\"I work alongside teams, not above them.\"},{\"title\":\"Impact over activity\",\"desc\":\"Outcomes that move the business, not vanity metrics.\"}]}',1,'2026-07-12 13:56:14.491'),
('cmrhse1lu000pvang1yv0g2ht','about','funfacts',3,'{\"eyebrow\":\"Beyond work\",\"items\":[{\"label\":\"Languages\",\"value\":\"Bangla, English\"},{\"label\":\"Interests\",\"value\":\"Startups, AI, brand strategy\"},{\"label\":\"Speaking\",\"value\":\"Hult Prize, campus & corporate events\"},{\"label\":\"Recognition\",\"value\":\"Net Impact VP, Hult Prize\"}]}',1,'2026-07-12 13:56:14.736'),
('cmrhse1sm000qvangeefmgcvd','services','hero',0,'{\"eyebrow\":\"Services\",\"title\":\"Engagements engineered for growth.\",\"subtitle\":\"Strategic support across the full journey — from diagnosis and positioning to market entry, scaling and leadership enablement.\"}',1,'2026-07-12 13:56:14.978'),
('cmrhse1zc000rvangq21bny0m','services','process',1,'{\"eyebrow\":\"How we work\",\"title\":\"A clear path from insight to impact.\",\"steps\":[{\"title\":\"Discovery\",\"desc\":\"Deep-dive into your business, market and goals.\"},{\"title\":\"Research\",\"desc\":\"Market, competitor and customer intelligence.\"},{\"title\":\"Strategy\",\"desc\":\"A prioritized, board-ready growth roadmap.\"},{\"title\":\"Implementation\",\"desc\":\"Hands-on execution with your team.\"},{\"title\":\"Optimization\",\"desc\":\"Measure, iterate and compound the gains.\"}]}',1,'2026-07-12 13:56:15.221'),
('cmrhse261000svangkw105w1s','contact','hero',0,'{\"eyebrow\":\"Contact\",\"title\":\"Let\'s talk about your next move.\",\"subtitle\":\"Whether you\'re entering a new market, repositioning a brand, or scaling revenue — I\'d love to hear about it.\"}',1,'2026-07-12 13:56:15.463'),
('cmrhse2ct000tvang3kd7wece','book','hero',0,'{\"eyebrow\":\"Book a meeting\",\"title\":\"Book a strategy session.\",\"subtitle\":\"Pick a time that works for you. You\'ll receive a confirmation with a Google Meet link once your session is approved.\"}',1,'2026-07-12 13:56:15.705');
/*!40000 ALTER TABLE `PageSection` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Post`
--

DROP TABLE IF EXISTS `Post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Post` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `excerpt` text DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `coverUrl` text DEFAULT NULL,
  `category` varchar(191) DEFAULT NULL,
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `authorName` varchar(191) NOT NULL DEFAULT 'Safiul Bashar Sabbir',
  `authorBio` text DEFAULT NULL,
  `readMins` int(11) NOT NULL DEFAULT 3,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `publishedAt` datetime(3) DEFAULT NULL,
  `seoTitle` varchar(191) DEFAULT NULL,
  `seoDesc` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Post_slug_key` (`slug`),
  KEY `Post_published_publishedAt_idx` (`published`,`publishedAt`),
  KEY `Post_category_idx` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Post`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Post` DISABLE KEYS */;
/*!40000 ALTER TABLE `Post` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Project`
--

DROP TABLE IF EXISTS `Project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Project` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `industry` varchar(191) DEFAULT NULL,
  `businessType` varchar(191) DEFAULT NULL,
  `role` varchar(191) DEFAULT NULL,
  `outcome` text DEFAULT NULL,
  `coverUrl` text DEFAULT NULL,
  `gallery` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`gallery`)),
  `description` longtext DEFAULT NULL,
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Project_slug_key` (`slug`),
  KEY `Project_published_orderIndex_idx` (`published`,`orderIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Project`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Project` DISABLE KEYS */;
INSERT INTO `Project` VALUES
('cmrhux0ef0024vaog5niti9v2','northbridge-market-entry','NorthBridge — Two-Region Market Entry','Retail','Mid-market retailer','Strategy & Go-To-Market','Launched in 2 new regions in 2 quarters with a validated entry playbook.','',NULL,NULL,'[\"Market Entry\",\"GTM\",\"Validation\"]',1,0,1,'2026-07-12 13:56:26.823','2026-07-12 13:56:26.823'),
('cmrhux0mi0025vaog7paoeiy5','vertex-growth-engine','Vertex SaaS — Growth Engine Rebuild','SaaS','B2B SaaS','Growth Strategy','Rebuilt acquisition + retention system; 2.3× qualified pipeline.','',NULL,NULL,'[\"Growth\",\"Retention\",\"Acquisition\"]',1,1,1,'2026-07-12 13:56:27.114','2026-07-12 13:56:27.114'),
('cmrhux0rv0026vaog190q2sh8','lumen-brand-reposition','Lumen Health — Brand Repositioning','Healthcare','Digital health','Brand Strategy','Sharper positioning that matched ambition and lifted conversion.','',NULL,NULL,'[\"Brand\",\"Positioning\",\"Messaging\"]',1,2,1,'2026-07-12 13:56:27.308','2026-07-12 13:56:27.308'),
('cmrhux0x80027vaogn9xl28k7','damex-operations-scale','Damex Digital — Operations at Scale','Technology','Agency','COO / Operations','Streamlined delivery and aligned teams to business goals.','',NULL,NULL,'[\"Operations\",\"Leadership\",\"Process\"]',0,3,1,'2026-07-12 13:56:27.500','2026-07-12 13:56:27.500'),
('cmrhux12o0028vaogevj13w4v','toolslab-launch','Tools Lab — 0→1 Product Launch','SaaS','Startup','Founder & COO','Took a tools venture from idea to launched product.','',NULL,NULL,'[\"0→1\",\"Launch\",\"Founder\"]',0,4,1,'2026-07-12 13:56:27.696','2026-07-12 13:56:27.696'),
('cmrhux1830029vaogquq1ph5h','orgagenic-transformation','Orgagenic — People & Ops Transformation','Manufacturing','SMB','HR & Operations','Built high-performing teams and optimized core processes.','',NULL,NULL,'[\"HR\",\"Transformation\",\"Teams\"]',0,5,1,'2026-07-12 13:56:27.891','2026-07-12 13:56:27.891');
/*!40000 ALTER TABLE `Project` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Resource`
--

DROP TABLE IF EXISTS `Resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Resource` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(191) DEFAULT NULL,
  `coverUrl` text DEFAULT NULL,
  `fileUrl` text DEFAULT NULL,
  `gated` tinyint(1) NOT NULL DEFAULT 1,
  `downloads` int(11) NOT NULL DEFAULT 0,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Resource_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Resource`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `Resource` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Service`
--

DROP TABLE IF EXISTS `Service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Service` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `category` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `excerpt` text DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `process` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`process`)),
  `coverUrl` text DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `seoTitle` varchar(191) DEFAULT NULL,
  `seoDesc` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Service_slug_key` (`slug`),
  KEY `Service_published_orderIndex_idx` (`published`,`orderIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Service`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Service` DISABLE KEYS */;
INSERT INTO `Service` VALUES
('cmrhuws30000uvaogwpca49y8','business-strategy','Business Strategy','Strategy','Compass','Audits, strategic planning and business-model optimization to set direction with confidence.',NULL,'[\"Business audits\",\"Strategic planning\",\"Business-model optimization\"]',NULL,NULL,1,0,1,NULL,NULL,'2026-07-12 13:56:16.044','2026-07-12 13:56:16.044'),
('cmrhuwsb4000vvaogkjawh500','brand-positioning','Brand Positioning','Brand','Sparkles','Sharpen your brand strategy, messaging and value proposition to stand apart.',NULL,'[\"Brand strategy\",\"Messaging & narrative\",\"Value proposition\",\"Competitive differentiation\"]',NULL,NULL,1,1,1,NULL,NULL,'2026-07-12 13:56:16.336','2026-07-12 13:56:16.336'),
('cmrhuwsgh000wvaoginl4ecn7','market-expansion','Market Expansion','Growth','Globe','Enter new markets and geographies with validated, low-risk expansion strategy.',NULL,'[\"International expansion\",\"New market entry\",\"Market validation\",\"Partnership strategy\"]',NULL,NULL,1,2,1,NULL,NULL,'2026-07-12 13:56:16.529','2026-07-12 13:56:16.529'),
('cmrhuwslu000xvaog3pbx5vdc','growth-strategy','Growth Strategy','Growth','TrendingUp','Scale revenue with a clear system for acquisition, retention and optimization.',NULL,'[\"Scaling\",\"Revenue optimization\",\"Customer acquisition\",\"Retention strategy\"]',NULL,NULL,1,3,1,NULL,NULL,'2026-07-12 13:56:16.723','2026-07-12 13:56:16.723'),
('cmrhuwsr7000yvaog2izht8ck','executive-consulting','Executive Consulting','Leadership','Users','Leadership coaching, decision support and transformation roadmaps for leaders.',NULL,'[\"Leadership coaching\",\"Decision support\",\"Transformation roadmap\"]',NULL,NULL,1,4,1,NULL,NULL,'2026-07-12 13:56:16.916','2026-07-12 13:56:16.916'),
('cmrhuwswm000zvaogkots6g3m','workshops','Workshops & Training','Enablement','Presentation','Corporate training, executive workshops and leadership sessions that stick.',NULL,'[\"Corporate training\",\"Executive workshops\",\"Leadership sessions\"]',NULL,NULL,1,5,1,NULL,NULL,'2026-07-12 13:56:17.111','2026-07-12 13:56:17.111');
/*!40000 ALTER TABLE `Service` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `SiteSettings`
--

DROP TABLE IF EXISTS `SiteSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SiteSettings` (
  `id` int(11) NOT NULL DEFAULT 1,
  `siteName` varchar(191) NOT NULL DEFAULT 'Safiul Bashar Sabbir',
  `tagline` text DEFAULT NULL,
  `logoUrl` text DEFAULT NULL,
  `faviconUrl` text DEFAULT NULL,
  `accentColor` varchar(191) NOT NULL DEFAULT '#5B9DFF',
  `goldColor` varchar(191) NOT NULL DEFAULT '#E8C88C',
  `email` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `whatsapp` varchar(191) DEFAULT NULL,
  `location` varchar(191) DEFAULT NULL,
  `mapEmbedUrl` text DEFAULT NULL,
  `calendlyUrl` text DEFAULT NULL,
  `socials` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`socials`)),
  `footerText` text DEFAULT NULL,
  `seoTitle` varchar(191) DEFAULT NULL,
  `seoDesc` text DEFAULT NULL,
  `ogImageUrl` text DEFAULT NULL,
  `googleTokens` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`googleTokens`)),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SiteSettings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `SiteSettings` DISABLE KEYS */;
INSERT INTO `SiteSettings` VALUES
(1,'Safiul Bashar Sabbir','Business Strategist',NULL,NULL,'#5B9DFF','#E8C88C','sbsabbir422@gmail.com','+880 1638 248647','8801638248647','Dhaka, Bangladesh',NULL,NULL,'{\"linkedin\":\"https://www.linkedin.com/in/sbsabbir\",\"x\":\"\",\"youtube\":\"\",\"instagram\":\"\",\"medium\":\"\",\"facebook\":\"\"}','Helping businesses expand into new markets, build impactful brands, and grow with AI-driven strategy.','Safiul Bashar Sabbir — Business Strategist','Business strategist driving strategic growth, brand positioning and market expansion for companies across 15+ countries.',NULL,NULL,'2026-07-12 13:56:08.805');
/*!40000 ALTER TABLE `SiteSettings` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Skill`
--

DROP TABLE IF EXISTS `Skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Skill` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 80,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `categoryId` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Skill_categoryId_idx` (`categoryId`),
  CONSTRAINT `Skill_categoryId_fkey` FOREIGN KEY (`categoryId`) REFERENCES `SkillCategory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Skill`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Skill` DISABLE KEYS */;
INSERT INTO `Skill` VALUES
('cmrhux1iw002bvaogci3iunpu','Corporate Strategy',92,0,'cmrhux1iw002avaogzewch394'),
('cmrhux1iw002cvaogg4p91zms','Growth Strategy',90,1,'cmrhux1iw002avaogzewch394'),
('cmrhux1iw002dvaogkzdvfssy','Market Research',85,2,'cmrhux1iw002avaogzewch394'),
('cmrhux1iw002evaog90eaab2o','Competitive Analysis',88,3,'cmrhux1iw002avaogzewch394'),
('cmrhux1iw002fvaog8evkbj7v','Financial Planning',80,4,'cmrhux1iw002avaogzewch394'),
('cmrhux1to002hvaogd33xkbc3','Brand Strategy',90,0,'cmrhux1to002gvaog008r8rws'),
('cmrhux1to002ivaog0xtrpi42','Marketing Automation',86,1,'cmrhux1to002gvaog008r8rws'),
('cmrhux1to002jvaogkw76d4oz','AI-Driven Marketing',84,2,'cmrhux1to002gvaog008r8rws'),
('cmrhux1to002kvaog7wuykzaj','Digital Transformation',82,3,'cmrhux1to002gvaog008r8rws'),
('cmrhux21t002mvaog1uzdljvu','Leadership',90,0,'cmrhux21t002lvaog91dtlmbn'),
('cmrhux21t002nvaog089b1905','Negotiation',85,1,'cmrhux21t002lvaog91dtlmbn'),
('cmrhux21t002ovaogqbrigugz','Operations',88,2,'cmrhux21t002lvaog91dtlmbn'),
('cmrhux21t002pvaogd4yljhqu','Team Building',87,3,'cmrhux21t002lvaog91dtlmbn');
/*!40000 ALTER TABLE `Skill` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `SkillCategory`
--

DROP TABLE IF EXISTS `SkillCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SkillCategory` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SkillCategory`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `SkillCategory` DISABLE KEYS */;
INSERT INTO `SkillCategory` VALUES
('cmrhux1iw002avaogzewch394','Business Strategy',0),
('cmrhux1to002gvaog008r8rws','Brand & Marketing',1),
('cmrhux21t002lvaog91dtlmbn','Leadership',2);
/*!40000 ALTER TABLE `SkillCategory` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `SpeakingTopic`
--

DROP TABLE IF EXISTS `SpeakingTopic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SpeakingTopic` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SpeakingTopic`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `SpeakingTopic` DISABLE KEYS */;
/*!40000 ALTER TABLE `SpeakingTopic` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Stat`
--

DROP TABLE IF EXISTS `Stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Stat` (
  `id` varchar(191) NOT NULL,
  `label` varchar(191) NOT NULL,
  `value` varchar(191) NOT NULL,
  `suffix` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Stat`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Stat` DISABLE KEYS */;
INSERT INTO `Stat` VALUES
('cmrhuwt4t0010vaogjhmu7lof','Businesses helped','120+',NULL,'Briefcase',0,1),
('cmrhuwtd30011vaog1h8wz8j9','Revenue influenced','$30M',NULL,'TrendingUp',1,1),
('cmrhuwtim0012vaogffkvaj6y','Industries served','18',NULL,'Layers',2,1),
('cmrhuwto30013vaogx5xef40o','Countries','15+',NULL,'Globe',3,1);
/*!40000 ALTER TABLE `Stat` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Testimonial`
--

DROP TABLE IF EXISTS `Testimonial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Testimonial` (
  `id` varchar(191) NOT NULL,
  `authorName` varchar(191) NOT NULL,
  `authorRole` varchar(191) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `avatarUrl` text DEFAULT NULL,
  `quote` text NOT NULL,
  `rating` int(11) DEFAULT 5,
  `type` enum('WRITTEN','VIDEO','LINKEDIN') NOT NULL DEFAULT 'WRITTEN',
  `videoUrl` text DEFAULT NULL,
  `linkedinUrl` text DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Testimonial_published_orderIndex_idx` (`published`,`orderIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Testimonial`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `Testimonial` DISABLE KEYS */;
INSERT INTO `Testimonial` VALUES
('cmrhuwz1x001xvaog98nb3js5','Ayesha Rahman','Founder & CEO','NorthBridge Retail',NULL,'Safiul reframed our entire market-entry approach. Within two quarters we\'d launched in two new regions with a plan the whole team believed in.',5,'WRITTEN',NULL,NULL,1,0,1,'2026-07-12 13:56:25.077'),
('cmrhuwz9z001yvaog0gav2h9g','Daniel Okoye','Managing Director','Vertex SaaS',NULL,'Rare mix of strategist and operator. He doesn\'t just hand you a deck — he rolls up his sleeves and makes the strategy real.',5,'WRITTEN',NULL,NULL,1,1,1,'2026-07-12 13:56:25.368'),
('cmrhuwzfc001zvaognbo6iulw','Maria Santos','VP Growth','Lumen Health',NULL,'Our brand positioning finally matches our ambition. Clear, sharp and grounded in real customer insight.',5,'LINKEDIN',NULL,NULL,1,2,1,'2026-07-12 13:56:25.561');
/*!40000 ALTER TABLE `Testimonial` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `role` varchar(191) NOT NULL DEFAULT 'admin',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES
('cmrhsdwpe0000vang6gtu29sn','admin@sabbir.com','Safiul Bashar Sabbir','$2b$10$8aFDgzxWfrXBlrs9iHkLlejH/1g/5hvpqurQ5KyDtgJUkQpfyg88u','admin','2026-07-12 12:45:36.338','2026-07-12 13:56:08.413');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ValueProp`
--

DROP TABLE IF EXISTS `ValueProp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ValueProp` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `orderIndex` int(11) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ValueProp`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `ValueProp` DISABLE KEYS */;
INSERT INTO `ValueProp` VALUES
('cmrhuwtw60014vaogyuy6t90m','Strategic thinking','I connect market insight, brand and execution into one coherent plan.','Compass',0,1),
('cmrhuwu490015vaog56u8zhuv','Data-driven decisions','Every recommendation is grounded in research and measurable outcomes.','BarChart3',1,1),
('cmrhuwu9m0016vaogsspyr9ar','ROI focus','I optimize for business value, not vanity metrics or activity.','Target',2,1),
('cmrhuwuf40017vaog0l9r2a8u','Leadership experience','COO and founder background — I\'ve run the operations I advise on.','Crown',3,1),
('cmrhuwukp0018vaogk3b1b9py','Cross-functional collaboration','I work across product, marketing, sales and ops to align teams.','Network',4,1),
('cmrhuwuq30019vaogb5mfiejf','Global perspective','Experience across 15+ countries and 18 industries.','Globe',5,1);
/*!40000 ALTER TABLE `ValueProp` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'u781705420_sbdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-08 12:53:49
